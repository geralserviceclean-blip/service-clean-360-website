# 🚀 Service Clean 360 - Website Oficial

## 📋 Projeto Completo
Website profissional para empresa de limpeza Service Clean 360.
Desenvolvido em Next.js 15 com todos os contactos reais configurados.

## 🔧 Instalação Rápida

### 1. Instalar Dependências
```bash
npm install
# ou
yarn install
# ou  
pnpm install
```

### 2. Executar em Desenvolvimento
```bash
npm run dev
# ou
yarn dev
# ou
pnpm dev
```

### 3. Abrir no Navegador
```
http://localhost:3000
```

## 📞 Contactos Configurados
- **Telefone:** +351 918 571 805
- **WhatsApp:** +351 256 935 288 (botão fixo)
- **Email:** geralserviceclean@gmail.com
- **Instagram:** @serviceclean360

## 🎯 Funcionalidades
- ✅ 4 páginas completas (Início, Serviços, Sobre, Contacto)
- ✅ Botão WhatsApp fixo no ecrã
- ✅ Formulários integrados com WhatsApp
- ✅ Design responsivo
- ✅ SEO otimizado
- ✅ Português de Portugal

## 🏗️ Build para Produção
```bash
npm run build
npm start
```

## ☁️ Deploy
- **Vercel:** vercel.com (recomendado)
- **Netlify:** netlify.com
- **Outros:** Qualquer serviço com Node.js

## 📁 Estrutura do Projeto
```
service-clean-360-website/
├── src/
│   ├── app/           # Páginas Next.js (App Router)
│   ├── components/    # Componentes React
│   ├── hooks/         # Hooks customizados
│   └── lib/          # Utilitários
├── public/           # Arquivos estáticos
├── package.json      # Dependências
└── next.config.ts    # Configuração Next.js
```

## 🎨 Personalização
- **Cores:** Editar src/app/globals.css
- **Conteúdo:** Editar componentes em src/components/
- **Contactos:** Já configurados, mas pode alterar se necessário

**🎉 Site pronto para usar! Desenvolvido com Next.js 15 + React 19 + TypeScript**
