# 🔧 Instalação - Service Clean 360

## ⚠️ IMPORTANTE: Resolver Erro de Diretórios

Se aparecer o erro: "Não foi possível encontrar nenhum diretório `pages` ou `app`"

### ✅ Solução:

1. **Verificar se a pasta `src/app` existe:**
```bash
ls -la src/app/
```

2. **Se não existir, o problema foi na extração. Tente:**
```bash
# Extrair novamente garantindo estrutura completa
tar -xzf service-clean-360-website.tar.gz --no-same-owner

# OU no Windows com 7-Zip/WinRAR:
# - Clique direito no arquivo .tar.gz
# - "Extrair aqui" ou "Extract here"
# - Certifique-se que mantém a estrutura de pastas
```

3. **Verificar estrutura obrigatória:**
```
service-clean-360-website/
├── src/
│   └── app/              ← OBRIGATÓRIO
│       ├── layout.tsx    ← OBRIGATÓRIO  
│       ├── page.tsx      ← OBRIGATÓRIO
│       ├── about/
│       ├── contact/
│       └── services/
├── package.json          ← OBRIGATÓRIO
└── next.config.ts        ← OBRIGATÓRIO
```

## 🚀 Instalação Normal

### 1. Instalar Node.js
- Baixar: https://nodejs.org (versão 18+)
- Verificar: `node --version`

### 2. Instalar Dependências
```bash
cd service-clean-360-website
npm install
```

### 3. Executar Projeto
```bash
npm run dev
```

### 4. Abrir Navegador
```
http://localhost:3000
```

## 🔍 Resolução de Problemas

### Erro: "Cannot find module 'next'"
```bash
rm -rf node_modules
rm package-lock.json
npm install
```

### Erro: "Port 3000 is already in use"
```bash
npm run dev -- --port 3001
```

### Erro de Permissões (Mac/Linux)
```bash
sudo npm install
```

## ✅ Verificação Final
- ✅ Pasta `src/app/` existe
- ✅ Arquivo `package.json` existe  
- ✅ Comando `npm run dev` funciona
- ✅ Site abre em `localhost:3000`

**🎯 Se tudo estiver correto, o site abrirá perfeitamente!**
