# ✨ Funcionalidades do Site Service Clean 360

## 🏠 Página Inicial
- Hero section com formulário de contacto rápido
- Grid de serviços principais
- Secção "Porquê escolher-nos"
- Testemunhos de clientes
- Call-to-action final

## 📋 Páginas
- **/** - Página inicial completa
- **/services** - Serviços detalhados
- **/about** - Sobre a empresa
- **/contact** - Contacto e formulários

## 💼 Serviços Incluídos
1. **Limpeza Empresarial** - Escritórios e corporações
2. **Limpeza de Ginásios** - Academias e centros desportivos
3. **Limpeza de Lojas** - Retalho e comércio
4. **Limpeza Industrial** - Fábricas e indústrias

## 📱 Funcionalidades
- ✅ Design totalmente responsivo
- ✅ Formulários de contacto funcionais
- ✅ Integração com WhatsApp
- ✅ Português de Portugal
- ✅ SEO optimizado
- ✅ Performance optimizada
- ✅ Imagens profissionais incluídas

## 🎨 Design
- Cores: Azul profissional + Verde + Branco
- Tipografia: Google Fonts (Inter)
- UI: shadcn/ui components
- CSS: Tailwind CSS
- Framework: Next.js 15

## 📞 Contactos Configurados
- Telefone: (+351) 999 999 999
- WhatsApp: (+351) 999 999 999
- Email: contacto@serviceclean360.pt

## 🔧 Tecnologias
- Next.js 15
- React 19
- TypeScript
- Tailwind CSS
- shadcn/ui
- Framer Motion (animações)
