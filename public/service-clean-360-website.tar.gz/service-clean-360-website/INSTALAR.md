# 🚀 Service Clean 360 - Instalação

## 📋 Pré-requisitos
- Node.js 18+ instalado
- npm ou pnpm

## 🔧 Instalação

### 1. Instalar dependências
```bash
npm install
# ou
pnpm install
```

### 2. Executar em desenvolvimento
```bash
npm run dev
# ou
pnpm run dev
```

### 3. Abrir no navegador
http://localhost:3000

## 🏗️ Build para produção
```bash
npm run build
npm start
# ou
pnpm run build
pnpm start
```

## 📱 Configurações Importantes

### Contactos
- Alterar números de telefone em todos os componentes
- Alterar emails de contacto
- Configurar WhatsApp com número real

### Domínio
- Registar domínio (serviceclean360.pt)
- Configurar DNS
- Deploy no Vercel, Netlify ou outro serviço

## 📁 Estrutura do Projeto
- `src/app/` - Páginas Next.js
- `src/components/` - Componentes React
- `public/` - Arquivos estáticos
- `package.json` - Dependências

## 🛠️ Personalização
- Alterar cores em `src/app/globals.css`
- Modificar conteúdo nos componentes
- Adicionar novas páginas em `src/app/`

## ☁️ Deploy Recomendado
1. **Vercel** (gratuito) - vercel.com
2. **Netlify** (gratuito) - netlify.com
3. **Hosting tradicional** com Node.js

Site criado com Next.js 15 + Tailwind CSS + shadcn/ui
